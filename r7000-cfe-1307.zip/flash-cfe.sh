#!/bin/sh

chmod +x ./mtd-write
echo "Flashing CFE..."
./mtd-write -i cfe_r7000.bin -d boot
echo "Done!"
